package kr.co.openeg.lab.filter.xss;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletRequestWrapper;

public class p043_XSSRequestWrapper extends HttpServletRequestWrapper {

    public p043_XSSRequestWrapper(HttpServletRequest request) {
        super(request);
    }

    @Override
    public String getParameter(String name) {
        String value = super.getParameter(name);
        return (value != null) ? sanitize(value) : null;
    }

    @Override
    public String[] getParameterValues(String name) {
        String[] values = super.getParameterValues(name);
        if (values != null) {
            for (int i = 0; i < values.length; i++) {
                values[i] = sanitize(values[i]);
            }
        }
        return values;
    }

    // XSS 공격 가능성이 있는 코드 제거
    private String sanitize(String input) {
        if (input == null) return null;
        String clean = input;
        // <script> 태그 제거
        clean = clean.replaceAll("(?i)<script.*?>.*?</script>", "");
        // onclick, onerror 등의 이벤트 핸들러 제거
        clean = clean.replaceAll("(?i)on\\w+\\s*=\\s*['\"][^'\"]*['\"]", "");
        // javascript: 문자열 제거
        clean = clean.replaceAll("(?i)javascript:", "");
        return clean;
    }
}
