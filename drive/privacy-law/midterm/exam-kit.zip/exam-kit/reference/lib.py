# 수업정리 HTML 생성 공통 모듈 — 템플릿의 CSS·JS는 그대로 쓰고 본문만 조립한다
import re

TPL = open('/mnt/user-data/uploads/수업정리-템플릿.html', encoding='utf-8').read()

# 템플릿에서 <style>…</style>, <script>…</script>를 그대로 떼어 온다 (레이아웃 변경 금지 규칙)
CSS = TPL.split('<style>', 1)[1].split('</style>', 1)[0]
JS = TPL.split('<script>', 1)[1].split('</script>', 1)[0]

# 과목 테마: 개인정보보호법률이해 (라이트 3줄 + 다크 3줄만 교체)
CSS = CSS.replace('--accent:#4F46E5;', '--accent:#059669;', 1)
CSS = CSS.replace('--accent-deep:#3730A3;', '--accent-deep:#065F46;', 1)
CSS = CSS.replace('--accent-soft:#E8E7FD;', '--accent-soft:#D8F5EA;', 1)
CSS = CSS.replace('--accent:#7C78F0;', '--accent:#10A37F;', 1)
CSS = CSS.replace('--accent-deep:#9C99F7;', '--accent-deep:#6EE7B7;', 1)
CSS = CSS.replace('--accent-soft:#22232E;', '--accent-soft:#12302A;', 1)
assert '#059669' in CSS and '#10A37F' in CSS

SUBJECT = '개인정보보호법률이해'
PROF = '이동재'


# ───────────── 작은 조각 헬퍼 ─────────────
def en(s):
    return f'<span class="en">({s})</span>'


def ul(items):
    return '<ul>' + ''.join(f'<li>{i}</li>' for i in items) + '</ul>'


def law(title, spec, note=None):
    """조문 원문 블록. spec: 문자열은 문단, 리스트는 호·목 목록(번호는 텍스트로 포함)."""
    out = [f'<div class="call"><div class="t">{title}</div>']
    for part in spec:
        if isinstance(part, list):
            out.append('<ul style="list-style:none;padding-left:6px">' +
                       ''.join(f'<li>{i}</li>' for i in part) + '</ul>')
        else:
            out.append(f'<p>{part}</p>')
    if note:
        out.append(f'<p style="font-size:13px;color:var(--ink-3)">{note}</p>')
    out.append('</div>')
    return ''.join(out)


def call(kind, title, body):
    # kind: warn / ask / link / extra / quote / '' (기본 카드)
    cls = 'call' + (f' {kind}' if kind else '')
    if not body.lstrip().startswith('<'):
        body = f'<p>{body}</p>'
    return f'<div class="{cls}"><div class="t">{title}</div>{body}</div>'


def table(head, rows):
    """rows: 셀 목록. 셀이 dict면 {'h':html,'rs':rowspan,'cs':colspan}."""
    th = ''.join(f'<th>{h}</th>' for h in head)
    body = []
    for r in rows:
        tds = []
        for c in r:
            if isinstance(c, dict):
                attrs = ''
                if c.get('rs'):
                    attrs += f' rowspan="{c["rs"]}"'
                if c.get('cs'):
                    attrs += f' colspan="{c["cs"]}"'
                tds.append(f'<td{attrs}>{c["h"]}</td>')
            else:
                tds.append(f'<td>{c}</td>')
        body.append('<tr>' + ''.join(tds) + '</tr>')
    return (f'<div class="tablewrap"><table><thead><tr>{th}</tr></thead>'
            f'<tbody>{"".join(body)}</tbody></table></div>')


def badges(*bs):
    # 교안 쪽수는 prof 스타일 배지로 표시 (PDF와 대조용)
    return '<div class="badges">' + ''.join(f'<span class="badge prof">{b}</span>' for b in bs) + '</div>'


def terms(items):
    return '<div class="terms">' + ''.join(
        f'<div class="term"><b>{k}</b><span class="e">{e}</span><p>{d}</p></div>' for k, e, d in items) + '</div>'


def q(n, text, typ, ans_lab, ans, choices=None):
    ch = ''
    if choices:
        ch = '<ol class="ch">' + ''.join(f'<li>{c}</li>' for c in choices) + '</ol>'
    return (f'<div class="q"><div class="qh"><span class="qn">Q{n}</span><span>{text}</span>'
            f'<span class="type">{typ}</span></div>{ch}'
            f'<div class="ans"><span class="lab">{ans_lab}</span>{ans}</div></div>')


def figure(svg, caption):
    return f'<figure>{svg}<figcaption>{caption}</figcaption></figure>'


# ───────────── SVG 도식 헬퍼 (인라인 style, fill 속성 명시) ─────────────
class Svg:
    def __init__(self, w, h, label, mid):
        self.w, self.h, self.aria, self.mid = w, h, label, mid
        self.parts = []

    def _text(self, x, y, s, fs=13, weight=700, color='var(--ink)', anchor='middle'):
        self.parts.append(
            f'<text x="{x}" y="{y}" text-anchor="{anchor}" '
            f'style="font-family:var(--font);font-size:{fs}px;font-weight:{weight};fill:{color}">{s}</text>')

    def box(self, x, y, w, h, lines, kind='main', fs=13):
        st = {
            'main': ('var(--surface)', 'var(--accent)', 'var(--ink)', ''),
            'solid': ('var(--accent)', 'var(--accent)', '#fff', ''),
            'end': ('var(--accent-soft)', 'var(--accent)', 'var(--accent-deep)', 'stroke-dasharray:4 3;'),
            'note': ('var(--line-2)', 'var(--line)', 'var(--ink-2)', ''),
        }[kind]
        fill, stroke, tc, dash = st
        self.parts.append(
            f'<rect x="{x}" y="{y}" width="{w}" height="{h}" rx="8" ry="8" fill="{fill}" '
            f'style="fill:{fill};stroke:{stroke};stroke-width:1.5;{dash}"/>')
        if isinstance(lines, str):
            lines = [lines]
        lh = fs + 5
        n = len(lines)
        y0 = y + h / 2 - (n - 1) * lh / 2 + fs * 0.36
        weight = 700 if kind != 'note' else 600
        for i, s in enumerate(lines):
            self._text(x + w / 2, round(y0 + i * lh, 1), s, fs=fs if kind != 'note' else fs - 1,
                       weight=weight, color=tc)

    def arrow(self, pts, dashed=False, head=True):
        p = ' '.join(f'{a},{b}' for a, b in pts)
        dash = 'stroke-dasharray:4 3;' if dashed else ''
        mk = f' marker-end="url(#ah-{self.mid})"' if head else ''
        self.parts.append(f'<polyline points="{p}" fill="none" '
                          f'style="fill:none;stroke:var(--ink-3);stroke-width:1.6;{dash}"{mk}/>')

    def label(self, x, y, s, anchor='middle', color='var(--accent-deep)', fs=11, weight=800):
        self._text(x, y, s, fs=fs, weight=weight, color=color, anchor=anchor)

    def poly(self, pts, fill, stroke, opacity=1):
        p = ' '.join(f'{a:.1f},{b:.1f}' for a, b in pts)
        self.parts.append(f'<polygon points="{p}" fill="{fill}" '
                          f'style="fill:{fill};fill-opacity:{opacity};stroke:{stroke};stroke-width:1.5"/>')

    def line(self, x1, y1, x2, y2, dashed=True):
        dash = 'stroke-dasharray:3 3;' if dashed else ''
        self.parts.append(f'<line x1="{x1}" y1="{y1}" x2="{x2}" y2="{y2}" '
                          f'style="stroke:var(--ink-3);stroke-width:1.2;{dash}"/>')

    def render(self):
        defs = (f'<defs><marker id="ah-{self.mid}" viewBox="0 0 10 10" refX="9" refY="5" '
                f'markerWidth="7" markerHeight="7" orient="auto-start-reverse">'
                f'<path d="M0,0 L10,5 L0,10 z" fill="var(--ink-3)" style="fill:var(--ink-3)"/></marker></defs>')
        return (f'<svg viewBox="0 0 {self.w} {self.h}" role="img" aria-label="{self.aria}" '
                f'xmlns="http://www.w3.org/2000/svg">{defs}{"".join(self.parts)}</svg>')


# ───────────── 페이지 조립 ─────────────
def build(W):
    wk = W['week']
    ww = f'{wk:02d}'
    secs = W['sections']
    # 섹션 번호는 순서대로 자동 부여 → 목차·흐름 칩·제목 번호가 어긋나지 않게
    for i, s in enumerate(secs, 1):
        s['n'] = f'{i:02d}'

    toc = ''.join(f'<li><a href="#{s["id"]}"><span class="num">{s["n"]}</span>{s.get("nav", s["title"])}</a></li>'
                  for s in secs)
    flow = ''.join(f'<a href="#{s["id"]}"><b>{s["n"]}</b> {s.get("nav", s["title"])}</a>'
                   for s in secs if s['id'] not in ('sg', 'sq'))
    chk = ''.join(f'<label><input type="checkbox"><span>{c}</span></label>' for c in W['review'])
    keys = ''.join(f'<div class="key"><div class="n">핵심 {i}</div><p>{k}</p></div>'
                   for i, k in enumerate(W['keys'], 1))
    files = ''.join(f'<a class="file" href="{href}" target="_blank"><span class="ic">PDF</span>{lab}<em>{pg}p</em></a>'
                    for href, lab, pg in W['files'])
    files_html = f'''
    <!-- 수업 자료: 같은 폴더에 둔 PDF. 없으면 이 블록 전체를 지운다 -->
    <div class="files">{files}</div>''' if W['files'] else ''
    meta = ''.join(f'<span>{m}</span>' for m in W['meta'])

    body_secs = []
    rawitems = []
    scr = W.get('raw_kind') == 'screen'  # 발화가 없는 주차: 화면 필기 관찰 기록으로 대신
    rlab = '강의 화면 필기 기록' if scr else '강의 녹취 원문'
    for s in secs:
        rawblock = ''
        if s.get('raw'):
            # 섹션 안 접기: 그 섹션에 해당하는 강의 발언만, 녹취 표기 그대로
            txt = '\n'.join(f'[{t}] {r}' for t, r in s['raw'])
            rawblock = f'<details class="raw"><summary>{rlab} ({len(s["raw"])})</summary><div class="txt">{txt}</div></details>'
            for t, r in s['raw']:
                rawitems.append((t, r, s['id'], f'{s["n"]}. {s.get("nav", s["title"])}'))
        s['_raw'] = rawblock
        body_secs.append(f'''
  <!-- {s["n"]} -->
  <section id="{s["id"]}">
    <h2 class="st"><span class="sq">{s["n"]}</span>{s["title"]}</h2>
    {s.get("badges", "")}
    {s["body"]}
    {s["_raw"]}
  </section>''')

    def _sec(t):
        m, x = t.split(':'); return int(m) * 60 + int(x)
    rawitems.sort(key=lambda r: _sec(r[0]))
    rawlist = ''.join(f'''
    <div class="rawitem">
      <div class="seq">{i:02d}<span>{t}</span></div>
      <div>
        <div class="body">{r}</div>
        <div class="where"><a href="#{sid}">{lab}</a></div>
      </div>
    </div>''' for i, (t, r, sid, lab) in enumerate(rawitems, 1))
    vocab = ''.join(f'''
    <li class="vword">
      <div><span class="w">{w}</span><span class="ipa">{ipa}</span><span class="pos">{pos}</span></div>
      <div><p class="mean">{mean}</p>
      <p class="ex">{ex}<span class="ko">{ko}</span></p></div>
    </li>''' for w, ipa, pos, mean, ex, ko in W['vocab'])

    title = f'{SUBJECT} {wk}주차 1차시 — {W["title_plain"]}'
    return f'''<!DOCTYPE html>
<html lang="ko" data-theme="light">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>{title}</title>
<link rel="stylesheet" href="https://cdn.jsdelivr.net/gh/orioncactus/pretendard@v1.3.9/dist/web/variable/pretendardvariable.min.css">
<style>{CSS}</style>
</head>
<body class="hide-ans">
<div id="scrollbar"></div>

<div class="topbar">
  <a class="back" href="../"><i></i>{SUBJECT}</a>
  <div class="search"><input id="q" type="search" placeholder="찾기 (Enter로 다음)" aria-label="문서 내 검색"><span class="hit" id="hit"></span></div>
  <div class="tools">
    <button class="tbtn" id="ansBtn">정답 가리기</button>
    <button class="tbtn" id="vocabBtn">단어장</button>
    <button class="tbtn" id="rawBtn">{"화면 필기" if scr else "필기 원문"}</button>
    <button class="tbtn" id="themeBtn">다크</button>
    <button class="tbtn" id="printBtn">🖨</button>
  </div>
</div>

<div class="wrap">

<!-- ═══════════ 사이드 패널 ═══════════ -->
<aside class="side">
  <div class="panel">
    <div class="subject">{SUBJECT}</div>
    <div class="when">{wk}주차 1차시 · {W["date"]}</div>

    <div id="tocWrap">
      <div class="cap">목차</div>
      <ul class="toc" id="toc">{toc}</ul>
      <hr>
      <div class="cap">복습 체크</div>
      <div class="chk">{chk}</div>
      <div class="pbar"><i id="barFill"></i></div>
    </div>

    <div id="rawNav" hidden>
      <div class="cap">{'강의 화면 필기' if scr else '강의 녹취 발췌'}</div>
      <p style="font-size:13px;opacity:.85;margin:0 0 12px;line-height:1.6">{'강의 화면에 교수님이 그은 붉은 필기 관찰' if scr else '강의 녹취에서 뽑은 핵심 발언'} <b id="rawTotal">0</b>개를 {'' if scr else '고치지 않고 '}영상 시각 순으로 모아둔 페이지입니다.</p>
      <hr>
      <div class="cap">확인 방법</div>
      <p style="font-size:12.5px;opacity:.8;margin:0;line-height:1.65">여기 있는 내용이 본문에 다 반영됐는지 대조하세요. 각 항목의 링크를 누르면 정리된 위치로 이동합니다.</p>
    </div>

    <div id="vocabNav" hidden>
      <div class="cap">단어장</div>
      <p style="font-size:13px;opacity:.85;margin:0 0 12px;line-height:1.6">이번 차시에 나온 전공 필수 단어 <b id="vTotal">0</b>개입니다.</p>
      <hr>
      <div class="cap">사용법</div>
      <p style="font-size:12.5px;opacity:.8;margin:0;line-height:1.65">뜻 가리기를 켜면 회색 칸을 눌러 하나씩 확인할 수 있습니다. 퀴즈는 아래 목록에서 문제를 자동으로 만듭니다.</p>
    </div>
  </div>
</aside>

<main>
<!-- ═══════════ 본문 뷰 ═══════════ -->
<div id="viewNote">

  <div class="hero" data-w="{ww}">
    <span class="chip">{wk}주차 · 1차시</span>
    <button class="chip extra-chip" id="extraChip"></button>
    <h1>{W["title"]}</h1>
    <p class="sub">{W["sub"]}</p>
    <div class="metaline">{meta}</div>{files_html}
  </div>

  <nav class="flow">{flow}</nav>

  <div class="keys">{keys}</div>
{"".join(body_secs)}

  <footer><span>{SUBJECT} · {wk}주차 1차시 · {W["date"].split(" ")[0]}</span><span>jaealee.com</span></footer>
</div>

<!-- ═══════════ 단어장 뷰 ═══════════ -->
<div id="viewVocab" hidden>
  <div class="hero" data-w="A–Z">
    <span class="chip">{wk}주차 1차시 단어장</span>
    <h1>{SUBJECT} 필수 용어</h1>
    <p class="sub">이번 차시 교안에 나온 개념 중 영문 법령·가이드라인·논문에서 다시 만날 단어만 골랐습니다.</p>
  </div>

  <div class="vhead">
    <input type="search" id="vq" placeholder="단어 · 뜻으로 찾기">
    <button class="tbtn" id="maskBtn">뜻 가리기</button>
    <button class="tbtn" id="quizBtn">퀴즈 풀기</button>
    <span style="font-size:13px;color:var(--ink-3);font-weight:600" id="vcount"></span>
  </div>

  <ul class="vlist" id="vlist">{vocab}
  </ul>

  <div class="quizbox" id="quiz">
    <div class="qq" id="quizQ"></div>
    <div class="opts" id="quizOpts"></div>
    <div class="score" id="quizScore"></div>
  </div>
</div>
<!-- ═══════════ 필기 원문 뷰 ═══════════ -->
<div id="viewRaw" hidden>
  <div class="hero" data-w="RAW">
    <span class="chip">{wk}주차 1차시 {'강의 화면 필기 기록' if scr else '강의 녹취 발췌'}</span>
    <h1>{'강의 화면에 표시하신 곳' if scr else '강의에서 하신 말 그대로'}</h1>
    <p class="sub">{f'이번 주차는 강의 음성을 확보하지 못해, 영상({W["video"]}) 화면에서 관찰한 붉은 필기 위치를 시각 순으로 모았습니다. 관찰 시각은 필기가 처음 보인 정지화면 시각이라 실제로 그은 시각과 조금 다를 수 있습니다. 전체 기록은 같은 폴더의 txt 파일에 있습니다.' if scr else f'강의 영상 녹취({W["video"]})에서 본문에 반영한 핵심 발언을 영상 시각 순으로 모았습니다. 자동 음성 인식 결과라 오인식도 고치지 않고 그대로 두었습니다. 전체 녹취는 같은 폴더의 txt 파일에 있습니다.'}</p>
  </div>

  <div class="rawnote" id="rawlist">{rawlist}
  </div>
</div>

</main>
</div>

<script>{JS}</script>
</body>
</html>
'''


# ───────────── 강의 녹취 반영 헬퍼 ─────────────
def sec(S, sid):
    for s in S:
        if s['id'] == sid:
            return s
    raise KeyError(sid)


def lec(S, sid, html='', raw=None, top=False, badge=None):
    """sid 섹션에 강의 내용(html)을 덧붙이고 녹취 발췌(raw)를 단다. top=True면 본문 맨 앞에."""
    s = sec(S, sid)
    if html:
        s['body'] = (html + s['body']) if top else (s['body'] + html)
    if raw:
        s.setdefault('raw', []).extend(raw)
    if badge:
        bs = ''.join(f'<span class="badge {k}">{t}</span>' for k, t in badge)
        s['badges'] = s.get('badges', '').replace('</div>', bs + '</div>', 1) if s.get('badges') else f'<div class="badges">{bs}</div>'


def quote(title, text, t=None):
    # 교수님 말씀 인용 — 녹취 의미를 살려 다듬은 문장. 원문은 녹취 발췌에 그대로 남긴다
    stamp = f' <span class="en">({t})</span>' if t else ''
    return f'<div class="call quote"><div class="t">{title}{stamp}</div><p>{text}</p></div>'
