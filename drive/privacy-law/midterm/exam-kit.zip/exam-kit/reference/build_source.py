# 참고용 원본: 개인정보보호법률이해 주차별 정리 페이지 생성기(lib.py), 주차 스크립트 예시(w7.py), 소스 JSON 생성기(build_source.py).
# 경로(/home/claude)와 주차 스크립트 구조에 묶여 있어 그대로는 실행되지 않습니다. 구조를 참고할 때만 보세요.
# 중간고사 대비 통합 소스 생성: python3 build_source.py
# 7개 주차 스크립트(w1~w7.py)의 섹션 데이터를 그대로 읽어 하나의 JSON으로 합친다.
# 손으로 다시 옮기지 않고 기존 원본에서 뽑으므로 페이지와 내용이 어긋나지 않는다.
import sys, re, json, importlib
sys.path.insert(0, '/home/claude')
from bs4 import BeautifulSoup
import lib

CUR = {'week': 0}
TERMS = []

_terms = lib.terms
def terms_rec(items):
    # 용어 정리 항목을 주차 정보와 함께 따로 모아 둔다
    for k, e, d in items:
        TERMS.append({'week': CUR['week'], 'term': k, 'en': e, 'desc': d})
    return _terms(items)
lib.terms = terms_rec

def clean(t):
    return re.sub(r'\s+', ' ', t).strip()

def text_of(html):
    soup = BeautifulSoup(html, 'html.parser')
    for s in soup.find_all('svg'):
        s.decompose()          # 도식 안의 글자는 검색에 노이즈라 본문 텍스트에서 뺀다
    for tag in soup.find_all(['p', 'li', 'tr', 'td', 'th', 'div', 'h3', 'br', 'figcaption', 'span', 'a']):
        tag.insert_after(' ')  # 블록 요소 사이에만 공백 → <b> 같은 인라인 태그 앞뒤로 공백이 끼지 않게
    return clean(soup.get_text(''))

LAW_HINT = re.compile(r'(법|시행령|시행규칙|기준|지침|고시|규정)')

weeks, sections, laws, callouts, checks, lectures = [], [], [], [], [], []
for n in range(1, 8):
    CUR['week'] = n
    m = importlib.import_module(f'w{n}')
    W = m.W
    lib.build(W)                     # 섹션 번호(n) 부여 + 녹취 블록 생성까지 같은 로직으로
    weeks.append({
        'week': n, 'date': W['date'], 'title': W['title'], 'title_plain': W['title_plain'],
        'sub': W['sub'], 'keys': [text_of(k) for k in W['keys']],
        'page': f'lecture/week{n:02d}/{n:02d}-1.html',
        'files': [{'path': f'lecture/week{n:02d}/{h}', 'label': l, 'pages': p} for h, l, p in W['files']],
        'video': W.get('video', ''), 'review': [text_of(r) for r in W['review']],
    })
    for s in W['sections']:
        sid = f"w{n}-{s['id']}"
        html = s['body']
        soup = BeautifulSoup(html, 'html.parser')
        if s['id'] == 'sq':
            for c in soup.select('div.call'):
                t = c.find(class_='t')
                checks.append({'week': n, 'title': clean(t.get_text(' ')) if t else '',
                               'text': text_of(''.join(str(x) for x in c.contents if x is not t)),
                               'kind': [k for k in c.get('class', []) if k != 'call'][0] if len(c.get('class', [])) > 1 else ''})
            continue
        if s['id'] in ('sg', 'sx'):
            continue                 # 용어는 terms로, 예상 문제는 이번 소스에서 제외(교수님 질문만 사용)
        law_ids = []
        for i, c in enumerate(soup.select('div.call')):
            cls = c.get('class', [])
            t = c.find(class_='t')
            title = clean(t.get_text(' ')) if t else ''
            body = text_of(''.join(str(x) for x in c.contents if x is not t))
            if cls == ['call'] and LAW_HINT.search(title):
                lid = f'{sid}-L{i}'
                laws.append({'id': lid, 'week': n, 'section': sid, 'title': title, 'text': body})
                law_ids.append(lid)
            elif len(cls) > 1:
                callouts.append({'week': n, 'section': sid, 'kind': cls[1], 'title': title, 'text': body})
        badges = [clean(b.get_text()) for b in BeautifulSoup(s.get('badges', ''), 'html.parser').select('.badge')]
        marks = list(dict.fromkeys(clean(x.get_text(' ')) for x in soup.find_all('mark')))
        raw = [{'t': t, 'text': r} for t, r in s.get('raw', [])]
        for r in raw:
            lectures.append({'week': n, 'section': sid, **r})
        sections.append({
            'id': sid, 'week': n, 'no': s['n'], 'title': text_of(s['title']), 'nav': s.get('nav', ''),
            'badges': badges, 'marks': marks, 'laws': law_ids,
            'text': text_of(html), 'html': html, 'lecture': raw,
            'page': f"lecture/week{n:02d}/{n:02d}-1.html#{s['id']}",
        })

# ── 교수님 질문 (교안 퀴즈 · 교안 질의응답 · 강의 중 질문) ──
w1 = importlib.import_module('w1')
questions = []
sk = next(s for s in w1.W['sections'] if s['id'] == 'sk')
questions.append({'id': 'q-w1-p7', 'week': 1, 'kind': '교안 퀴즈', 'where': '교안 p.7 · 강의 16:50',
                  'q': '생년월일과 혈액형은 개인정보에 해당되는가?',
                  'a': '교수님 정답 미공개. 교안 기준 풀이: 그 자체만으로는 특정 개인을 알아보기 어려워 개인정보가 아닐 수 있으나, 이름 등 다른 정보와 쉽게 결합하여 알아볼 수 있으면 개인정보에 해당(제2조 제1호 나목).',
                  'detail': '강의에서는 정답을 말하지 않고, “제2조 정의만으로는 판별이 모호하다 → 질의응답 모음집을 보자”로 넘어가는 질문으로 썼다(16:50). 교안 p.30 “모든 항목이 그 자체만으로는 개인정보가 되지 않을 수 있음”.', 'section': 'w1-sk'})
for i, row in enumerate(w1.qa_rows, 1):
    head = BeautifulSoup(row[0], 'html.parser')
    for e in head.select('.en'):
        e.decompose()
    title = clean(head.get_text(' ')).replace(f'Q{i} ', '', 1)
    questions.append({'id': f'q-w1-qa{i}', 'week': 1, 'kind': '교안 질의응답',
                      'where': f'교안 질의응답 모음집 Q{i}', 'q': title,
                      'a': text_of(row[1]), 'detail': text_of(row[2]), 'section': 'w1-s3'})

LQ = [  # 강의 중 교수님이 직접 던진 질문 (녹취 시각 · 원문 확인)
    (2, '73:14', '시행령 제18조 단서에 해당하면 “민감정보임에도 처리할 수 있다”는 뜻인가?',
     '아니다. 처리할 수 있는 게 아니라 애초에 민감정보로 보지 않는다는 뜻.', 'w2-s11'),
    (3, '13:28', '고유식별정보의 처리 제한(제24조)과 주민등록번호 처리 제한(제24조의2)의 차이점은?',
     '주민등록번호는 정보주체의 동의를 받았다고 처리할 수 있는 정보가 아니다. 법률·대통령령 등의 구체적 근거, 급박한 생명·신체·재산 이익, 보호위원회 고시인 경우에만 처리 가능.', 'w3-s2'),
    (3, '47:26', '(여행지 등에서) 사진을 찍을 때 카메라에 지나가는 사람이 나오면 개인정보보호법 위반인가?',
     '아니다. 고정형은 “누구든지”가 수범자지만, 이동형 영상정보처리기기 운영 제한(제25조의2)은 업무를 목적으로 하는 자만 규제한다.', 'w3-s5'),
    (3, '54:02', '드론 항공 촬영처럼 촬영 사실을 개별 표시하기 어려운 경우에는 어떻게 하는가?',
     '보호위원회가 구축하는 인터넷 사이트에 공지하는 방법으로 알리면 충분하다.', 'w3-s5'),
    (4, '34:38', '아무나 한 명 뽑아 개인정보 보호책임자로 지정하면 되는가?',
     '아니다. 자격요건이 있다. 민간은 기준이 덜 구체적이고(5명 이상이면 사업주·대표자·임원 중), 공공기관은 기관별로 명확.', 'w4-s6'),
    (4, '44:58', '유출 통지의 “지체 없이”는 얼마나 빨리인가?',
     '72시간 이내(시행령 제39조 ①). 단, 긴급 조치가 필요하거나 천재지변 등 부득이한 경우에는 해당 사유가 해소된 후 지체 없이.', 'w4-s8'),
    (4, '47:55', '정보주체의 연락처를 알 수 없어 유출 통지를 못 할 때는 어떻게 하는가?',
     '정보주체가 쉽게 알 수 있도록 자신의 인터넷 홈페이지에 30일 이상 게시(홈페이지가 없으면 사업장 등 보기 쉬운 장소에 30일 이상 게시).', 'w4-s8'),
    (6, '16:09', '동의 없이 오는 광고성 정보(제50조 ① 단서)를 중단시킬 방법은 없는가?',
     '있다. 수신거부 의사를 표시하거나 사전 동의를 철회하면 더 이상 전송할 수 없다(제50조 ②).', 'w6-s3'),
    (6, '29:56', '광고 수신동의 확인 주기 “2년마다”란?',
     '매 2년이 되는 해의 수신동의를 받은 날과 같은 날 전까지(시행령 제62조의3 ①).', 'w6-s4'),
    (6, '32:01', '고지를 받은 정보주체는 피드백을 줘야 하는가?',
     '불필요하다. 고지·통지·안내 중 피드백이 필요한 것은 동의뿐.', 'w6-s5'),
    (6, '37:04', '고지와 통지의 차이는?',
     '고지 = 사전에 알리는 것, 통지 = 사후에 알리는 것. 제20조(정보주체 이외로부터 수집한 개인정보의 출처 통지)는 사후이므로 통지 사항.', 'w6-s5'),
    (6, '68:30', '제58조의2(시간·비용·기술을 합리적으로 고려할 때 다른 정보를 사용해도 더 이상 개인을 알아볼 수 없는 정보)에 해당하는 정보의 이름은?',
     '익명정보. 개인정보보호법이 적용되지 않는다. 가명정보는 추가정보와 결합하면 복원 가능하므로 개인정보로 본다.', 'w6-s10'),
    (7, '09:21', '(영업양도 허용 요건과 관련해) 고지와 통지의 차이를 기억하는가?',
     '고지는 사전, 통지는 사후. 단 제27조 ① 양도자는 “미리” 알린다는 점 주의.', 'w7-s2'),
    (7, '15:24', '제3자 제공 동의를 받을 때 정보주체에게 알려야 하는 사항은?',
     '5가지: 제공받는 자 / 제공받는 자의 이용 목적 / 제공하는 항목 / 제공받는 자의 보유·이용 기간 / 동의 거부권과 불이익 (자목항기거, 제17조 ②).', 'w7-s3'),
    (7, '18:57', '카카오택시 이용자가 택시기사에게 정보가 갈 때마다 매번 동의해야 하는가?',
     '아니다. 당초 수집 목적과 합리적으로 관련된 범위(제17조 ④, 시행령 제14조의2)라 동의 없이 제공 가능.', 'w7-s3'),
    (7, '65:06', '법 제26조 제1항 제3호(위탁 문서에 포함할 “대통령령으로 정한 사항”)는 무엇이었나?',
     '시행령 제28조 ①: 위탁업무의 목적·범위 / 재위탁 제한 / 접근 제한 등 안전성 확보 조치 / 관리 현황 점검 등 감독 / 수탁자 의무 위반 시 손해배상 등 책임.', 'w7-s10'),
]
for i, (wk, t, qq, aa, sec) in enumerate(LQ, 1):
    questions.append({'id': f'q-w{wk}-t{t.replace(":", "")}', 'week': wk, 'kind': '강의 중 질문',
                      'where': f'{wk}주차 강의 {t}', 'q': qq, 'a': aa, 'detail': '', 'section': sec})

# ── 교안 원문 (쪽 단위) ──
SRC = {1: '/mnt/user-data/uploads/privacylaw_w1.md', 2: '/mnt/user-data/uploads/privacylaw_w2.md',
       3: '/mnt/user-data/uploads/privacylaw_w3.md', 4: '/mnt/user-data/uploads/privacylaw_w4.md',
       5: '/mnt/user-data/uploads/privacylaw_w5.md',
       6: '/mnt/user-data/uploads/privacy-law/lecture/week06/privacylaw_w6.md',
       7: '/mnt/user-data/uploads/privacy-law/lecture/week07/privacylaw_w7.md'}
slides = []
for wk, path in SRC.items():
    md = open(path, encoding='utf-8').read()
    parts = re.split(r'<!--\s*p\.(\d+)\s*-->', md)
    for j in range(1, len(parts), 2):
        body = re.sub(r'<!--.*?-->', '', parts[j + 1], flags=re.S).replace('---', '').strip()
        if body:
            slides.append({'week': wk, 'page': int(parts[j]), 'text': body})

# ── 강의 녹취 전문 (발화만, 시각 포함) ──
TX = {1: 'c1.txt', 2: 'c2.txt', 3: 'c3.txt', 4: 'c4s.txt', 5: 'c5s.txt', 6: 'c6.txt', 7: 'c7.txt'}
transcript = []
for wk, f in TX.items():
    for line in open(f'/home/claude/tx/{f}', encoding='utf-8'):
        mm = re.match(r'\[(\d+:\d\d)\] (.*)', line.strip())
        if mm:
            transcript.append({'week': wk, 't': mm.group(1), 'text': re.sub(r'\s*\[(불명확|표현 차이) [UM]\d+\]', '', mm.group(2))})

out = {
    'version': 1, 'generated': '2026-10-19',
    'course': {'name': '개인정보보호법률이해', 'prof': '이동재', 'email': 'dongjae.lee@kangwon.ac.kr'},
    'exam': {'name': '중간고사', 'date': '2026-10-20', 'weekday': '화', 'time': '18:00', 'format': 'LMS ‘퀴즈’ 항목, 온라인 실시간', 'scope': '1~7주차 (7주차 강의 77:35 “오늘 다룬 내용까지”)', 'ai': '사용 가능'},
    'weeks': weeks, 'sections': sections, 'laws': laws, 'callouts': callouts, 'terms': TERMS,
    'questions': questions, 'checks': checks, 'lecture_quotes': lectures, 'slides': slides, 'transcript': transcript,
}
json.dump(out, open('/home/claude/midterm/midterm-source.json', 'w', encoding='utf-8'), ensure_ascii=False, indent=1)
print({k: len(v) for k, v in out.items() if isinstance(v, list)})
