# reference

개인정보보호법률이해에서 실제로 쓴 생성 스크립트 원본입니다. 경로와 주차 스크립트 구조에 묶여 있어 그대로는 실행되지 않습니다.

- `lib.py` — 주차별 정리 페이지(NN-1.html) 생성기: `law()` `call()` `table()` `q()` `terms()` `build(W)`
- `w7.py` — 7주차 페이지 데이터 예시 (섹션 S, 주차 정보 W)
- `build_source.py` — w1~w7.py를 읽어 소스 JSON으로 합치는 스크립트
