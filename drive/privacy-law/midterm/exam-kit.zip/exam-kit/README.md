# 시험 검색 키트 (exam-kit)

개인정보보호법률이해 중간고사용으로 만든 **시험 검색 페이지 + AI 풀이 규칙**을 다른 과목·다른 AI 대화에서 그대로 다시 만들 수 있게 정리한 묶음입니다.

- 결과물 1: `index.html` — 검색 페이지. 파일 하나라서 더블클릭해도 열리고, 인터넷 연결 없이도 동작합니다.
- 결과물 2: AI 첨부 파일 5개 — `PROMPT.md` + `1-QUESTIONS.md` ~ `4-NOTES.md`

## 폴더 구성
| 경로 | 내용 |
|---|---|
| `MAKE-PROMPT.md` | **다른 AI 대화에 붙여 넣는 제작 지시문.** 새 과목을 처음부터 만들 때 사용 |
| `DESIGN.md` | 화면 구성·크기·동작 규칙(디자인 명세) |
| `PROMPT.template.md` | 시험 중 AI에 넣을 풀이 규칙 (`{{과목}}` 등만 바꾸면 됨) |
| `template/exam.tpl.html` | 검색 페이지 템플릿 (색은 `/*THEME*/` 자리에 들어감) |
| `themes/*.css` | 색 테마 5종 + `previews/`에 미리보기 사진 |
| `scripts/build_tiers.py` | 소스 JSON → AI 첨부 파일 1~4 생성 |
| `scripts/build_exam.py` | 소스 JSON + 템플릿 + 테마 + AI 파일 → `index.html` |
| `schema/source-schema.md` | 소스 JSON 형식 설명 |
| `schema/sample-source.json` | 2주차짜리 예시 소스 (형식 확인·시험 빌드용) |
| `examples/privacy-law/` | 실제로 쓴 `PROMPT.md`와 `midterm-source.json` |
| `reference/` | 원래 과목에서 쓴 생성 스크립트 원본(`lib.py`, `build_source.py`, `w7.py`) — 참고용, 그대로는 안 돌아감 |

## 사용 순서 (새 과목)
1. **자료 모으기** — 교안 PDF, 강의 녹취(발화) txt, 교수님이 낸 질문.
2. **소스 JSON 만들기** — `schema/source-schema.md` 형식으로. 다른 AI에 맡길 때는 `MAKE-PROMPT.md`를 그대로 붙여 넣으면 됩니다.
3. **AI 파일 만들기**
   ```
   python3 scripts/build_tiers.py --src source.json --out out
   ```
   그다음 `PROMPT.template.md`를 `out/PROMPT.md`로 복사하고 `{{과목}} {{교수}} {{시험}} {{범위}}`를 바꿉니다.
4. **페이지 만들기**
   ```
   python3 scripts/build_exam.py --src source.json --out out/index.html --theme themes/navy-sky.css \
     --files out/PROMPT.md out/1-QUESTIONS.md out/2-SLIDES.md out/3-TRANSCRIPT.md out/4-NOTES.md
   ```
5. **확인** — 페이지를 열어 검색 → Enter 연속 이동, 목차, AI 파일 저장을 눌러 봅니다. 시험 전에 쓸 AI에 `PROMPT.md`와 1·2를 넣고 한 문제를 풀려 봅니다.

> 내용을 고치면 3 → 4를 다시 실행해야 페이지 안의 AI 파일에도 반영됩니다.

## 색 테마 바꾸기
- 준비된 테마: `green-blue`(이번에 쓴 것) · `navy-sky` · `warm-coral` · `lavender` · `slate-teal`. 미리보기는 `themes/previews/`.
- 새 테마: 테마 파일 하나를 복사해서 값만 바꿉니다. 변수는 아래 22개이고, 템플릿은 이 변수만 보고 색을 칠합니다.

| 변수 | 쓰이는 곳 |
|---|---|
| `--bg` | 페이지 배경 (그라데이션 가능) |
| `--ink` `--ink-2` `--ink-3` | 제목 / 보조 글자 / 흐린 글자 |
| `--read` | 본문 창 글자 (가장 진하게) |
| `--primary` `--primary-2` `--primary-dark` | 주 색: 선택된 필터, 주차 번호, 링크 버튼, 조문 버튼 |
| `--primary-rgb` | 주 색의 R,G,B (반투명 배경용, 예 `31,111,181`) |
| `--primary-soft` | 본문 강조 표시 배경 |
| `--accent` `--accent-dark` `--accent-light` | 보조 색: 교수님 질문, 주차 필터, 현재 검색 위치 |
| `--accent-rgb` `--accent-soft` | 보조 색 반투명용 / 주의 상자 배경 |
| `--shade-rgb` `--deep-rgb` | 그림자 색 / AI 파일 상자 배경 |
| `--tint-a` `--tint-b` | 결과 선택·본문 창 상단 띠 |
| `--surface-2` `--line` `--line-2` | 표 머리칸 / 테두리 / 옅은 구분선 |

- 법 조문(파랑)·용어(청록)·확인(주황)·검색어 표시(노랑) 색은 종류를 구분하는 색이라 테마와 상관없이 고정입니다.
- 색 조합 원칙: 배경은 채도가 낮은 밝은 색, `--read`는 배경과 대비가 큰 진한 색, `--primary`와 `--accent`는 서로 다른 색 계열.

## 필요한 것
- Python 3 (추가 패키지 없음)
- 글꼴: Noto Sans KR (Google Fonts, 인터넷 연결 시). 연결이 없으면 맑은 고딕 등 기본 글꼴로 표시됩니다.
