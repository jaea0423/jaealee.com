"""시험 검색 페이지 만들기: 소스 JSON + 템플릿 + 색 테마 + AI 파일 → index.html 한 개.

사용법:
  python3 build_exam.py --src source.json --out index.html --theme ../themes/green-blue.css \
      --files PROMPT.md 1-QUESTIONS.md 2-SLIDES.md 3-TRANSCRIPT.md 4-NOTES.md
- 모든 데이터를 HTML 안에 넣으므로 인터넷 없이, 파일을 더블클릭(file://)해도 동작한다.
- --files로 준 파일은 페이지의 "AI에게 줄 파일" 카드를 누르면 저장된다(열리지 않음).
"""
import argparse, json, os
HERE = os.path.dirname(os.path.abspath(__file__))
ap = argparse.ArgumentParser()
ap.add_argument('--src', required=True, help='소스 JSON (schema/source-schema.md 형식)')
ap.add_argument('--out', default='index.html')
ap.add_argument('--tpl', default=os.path.join(HERE, '..', 'template', 'exam.tpl.html'))
ap.add_argument('--theme', default=os.path.join(HERE, '..', 'themes', 'green-blue.css'))
ap.add_argument('--files', nargs='*', default=[], help='페이지에 넣을 AI용 파일 경로들')
a = ap.parse_args()

def js_safe(obj):
    # </script> 가 데이터 안에 있어도 태그가 끊기지 않게 '</' 를 '<\/' 로 바꾼다
    return json.dumps(obj, ensure_ascii=False, separators=(',', ':')).replace('</', '<\\/')

data = json.load(open(a.src, encoding='utf-8'))
theme = ''.join(l for l in open(a.theme, encoding='utf-8') if not l.lstrip().startswith('/*'))
files = {os.path.basename(f): open(f, encoding='utf-8').read() for f in a.files}
html = open(a.tpl, encoding='utf-8').read()
html = html.replace('/*THEME*/', theme.strip()).replace('/*DATA*/', js_safe(data)).replace('/*FILES*/', js_safe(files))
open(a.out, 'w', encoding='utf-8').write(html)
print(a.out, round(len(html.encode()) / 1024), 'KB')
