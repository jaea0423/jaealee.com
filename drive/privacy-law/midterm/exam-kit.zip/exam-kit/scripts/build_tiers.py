"""소스 JSON → 우선순위별 AI 첨부 파일 4개.
  1-QUESTIONS.md  교수님 질문 (항목마다 등급 A/B/D)
  2-SLIDES.md     교안 원문
  3-TRANSCRIPT.md 강의 발화 (음성 인식)
  4-NOTES.md      주차별 정리 (AI 작성)
사용법: python3 build_tiers.py --src source.json --out 출력폴더
"""
import argparse, json, os
ap = argparse.ArgumentParser(); ap.add_argument('--src', required=True); ap.add_argument('--out', default='.')
a = ap.parse_args()
d = json.load(open(a.src, encoding='utf-8'))
W = {w['week']: w for w in d['weeks']}
def save(name, lines):
    t = '\n'.join(lines) + '\n'
    open(os.path.join(a.out, name), 'w', encoding='utf-8').write(t)
    print(name, len(t), '자')

def grade(q):
    # 등급 기준: 교수님이 답을 직접 말했는가. 소스에 grade가 있으면 그것을 우선한다
    if q.get('grade'): return q['grade'], q.get('grade_why', '')
    if '정답 미공개' in q['a']: return 'D', '교수님 정답 미공개 · 정리자 풀이'
    if q['kind'] == '교안 질의응답': return 'B', '교안 질의응답 모음 (교안 답)'
    return 'A', '교수님이 강의에서 직접 묻고 답함'

L = ['# 1-QUESTIONS — 교수님 질문 모음 (1순위)', '',
     '각 항목의 [등급]을 그대로 쓴다. A=교수님이 강의에서 직접 묻고 답함 / B=교안 질의응답 / D=교수님 정답 미공개(정리자 풀이).', '']
for q in d['questions']:
    g, why = grade(q)
    L += [f"## [{q['id']}] {q['week']}주차 · {q['kind']} · {q['where']} · 등급 {g}", f"- 질문: {q['q']}", f"- 답: {q['a']}"]
    L += ([f"- 근거: {q['detail']}"] if q.get('detail') else []) + [f"- 등급 사유: {why}", '']
save('1-QUESTIONS.md', L)

L = ['# 2-SLIDES — 교안 원문 (2순위)', '', '출처 표기: `2-SLIDES N주차 p.쪽`. 교안과 현행법이 다르면 교안 기준.', '']
seen = set()
for s in d['slides']:
    if s['week'] not in seen:
        seen.add(s['week']); L += [f"# {s['week']}주차 — {W[s['week']]['title_plain']}", '']
    L += [f"## {s['week']}주차 p.{s['page']}", s['text'].strip(), '']
save('2-SLIDES.md', L)

L = ['# 3-TRANSCRIPT — 강의 발화 전문 (3순위)', '',
     '자동 음성 인식 결과라 조문 번호·숫자 오인식이 있다. 숫자·조문 번호는 2-SLIDES로 확인한다.',
     '출처 표기: `3-TRANSCRIPT N주차 mm:ss`.', '']
cur = None
for t in d['transcript']:
    if t['week'] != cur:
        cur = t['week']; L += ['', f"# {cur}주차 — {W[cur]['title_plain']}", '']
    L.append(f"[{t['week']}주차 {t['t']}] {t['text']}")
save('3-TRANSCRIPT.md', L)

L = ['# 4-NOTES — 주차별 정리 (4순위 · AI 작성)', '',
     '교안·강의 발화를 바탕으로 AI가 정리한 자료다. 정답을 독립 검증하지 않았다. ‘보충’ 표시는 교안·강의 밖 내용.',
     '출처 표기: `4-NOTES 섹션ID` (예: 4-NOTES w5-s3).', '']
for w in d['weeks']:
    n = w['week']
    L += [f"# {n}주차 — {w['title_plain']} ({w['date']})", '', '핵심: ' + ' / '.join(w['keys']), '']
    for s in [s for s in d['sections'] if s['week'] == n]:
        b = ' · '.join(s['badges'])
        L += [f"## [{s['id']}] {s['title']}" + (f" ({b})" if b else ''), '', s['text'], '']
    ch = [c for c in d['checks'] if c['week'] == n]
    if ch: L += [f"## [{n}주차] 확인 필요·교안 차이", ''] + [f"- {c['title']}: {c['text']}" for c in ch] + ['']
L += ['# 용어', ''] + [f"- {t['term']} ({t['en']}, {t['week']}주차): {t['desc']}" for t in d['terms']]
save('4-NOTES.md', L)
