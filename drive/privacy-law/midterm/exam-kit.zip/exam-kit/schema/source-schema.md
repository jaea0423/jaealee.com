# 소스 JSON 형식

검색 페이지(`build_exam.py`)와 AI 파일(`build_tiers.py`)이 함께 쓰는 하나의 JSON입니다. 예시는 `sample-source.json`, 실제 예는 `../examples/privacy-law/midterm-source.json`.

`?` 표시는 없어도 되는 항목입니다.

```jsonc
{
  "version": 1,
  "generated": "2026-10-19",
  "course": { "name": "과목명", "prof": "교수 이름", "author?": "정리한 사람" },
  "exam": {
    "name": "중간고사", "date": "2026-10-20", "weekday": "화", "time": "18:00",
    "format": "LMS 퀴즈, 온라인 실시간", "format_short?": "LMS 퀴즈 · 실시간",
    "scope": "1~7주차", "ai": "사용 가능"
  },
  // 링크 규칙. {W}=01 같은 두 자리, {w}=1 같은 숫자. 없으면 아래 기본값
  "paths?": { "notes": "../lecture/week{W}/{W}-1.html", "pdf": "../lecture/week{W}/{W}-1-material.pdf" },

  "weeks": [ { "week": 1, "date": "2026.09.01 (화)", "title_plain": "주차 제목", "keys": ["핵심 문장", "..."] } ],

  // 개념 섹션 = 본문 창에 보이는 단위
  "sections": [ {
    "id": "w1-s1", "week": 1, "no": "01",
    "title": "섹션 제목", "nav": "목차용 짧은 이름",
    "badges": ["교안 p.2–5"],          // 출처 배지
    "marks": ["핵심어"],               // 검색 가산점용 키워드
    "text": "검색용 순수 텍스트",
    "html": "<p>본문 HTML</p>",        // DESIGN.md 4절의 클래스 사용
    "lecture": [ { "t": "01:27", "text": "이 섹션 관련 강의 발화" } ]
  } ],

  "laws":     [ { "id": "w1-l1", "week": 1, "section": "w1-s1", "title": "OO법 제2조(정의)", "text": "조문 원문" } ],
  "callouts": [ { "week": 1, "section": "w1-s1", "kind": "warn|quote|ask|extra", "title": "제목", "text": "내용" } ],
  "terms":    [ { "week": 1, "term": "용어", "en": "English", "desc": "설명" } ],

  // 교수님 질문 = AI 1순위
  "questions": [ {
    "id": "q-w4-t4458", "week": 4,
    "kind": "강의 중 질문 | 교안 퀴즈 | 교안 질의응답",
    "where": "4주차 강의 44:58",
    "q": "질문", "a": "답", "detail": "근거(없으면 빈 문자열)",
    "section": "관련 섹션 id",
    "grade?": "A|B|D", "grade_why?": "등급 사유"
  } ],

  "checks":     [ { "week": 1, "title": "확인 필요·교안 차이", "text": "내용" } ],
  "slides":     [ { "week": 1, "page": 3, "text": "교안 그 쪽의 글 (마크다운 표·# 제목 가능)" } ],
  "transcript": [ { "week": 1, "t": "01:27", "text": "강의 발화 한 줄" } ],
  "lecture_quotes?": []
}
```

## 등급 자동 판정 (`grade`가 없을 때)
- 답에 `정답 미공개`가 있으면 **D** (교수님이 답을 말하지 않음 → 정리자 풀이)
- `kind`가 `교안 질의응답`이면 **B**
- 나머지(교수님이 강의에서 묻고 답함)는 **A**

## 만들 때 주의
- `id`는 겹치지 않게. 섹션은 `w주차-s번호`, 질문은 `q-w주차-t분초` 형식을 권장합니다.
- `text`에는 HTML 태그 없이 순수 글자만. 인라인 태그(`<b>`) 앞뒤에 공백이 생기지 않게 뽑아야 검색이 정확합니다.
- 교안 밖 내용은 `html`에서 `.ext` 또는 `.call.extra`로 표시합니다(AI가 D로 판단하는 근거).
- 강의 발화는 음성 인식 결과라 숫자·용어가 틀릴 수 있으니, 질문의 답·조문은 교안으로 확인한 값을 넣습니다.
